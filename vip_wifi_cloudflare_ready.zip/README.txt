Vip Wifi Voucher Cloudflare Worker

Upload worker.js and wrangler.toml to the GitHub repository connected to the Worker.
Keep BOT_TOKEN only as a Cloudflare Worker Secret named BOT_TOKEN.
After deploy, set the Telegram webhook to the Worker workers.dev URL.
